
//Name:Roaa Abdullah Alzhrani
//ID:2005863
//IAR
//----------------
var Arrayy=[];  
var Arraycopy=[]; 
var counterquickSelect_lomuto = 0;
var counterquicksort_sedqwick=0;
var size=7500;     
fillarray(size,Arrayy);
var k = median(Arrayy);
//Copy array to send to the other method 
for( var i=0;i<Arrayy.length;i++){
  Arraycopy[i]=Arrayy[i];
 }
//---------------
function median(Arrayy){
  var right=0;
  var left=Arrayy.length-1;
  var k =Math.floor((left+right)/2);
  return k;}
   
//----------------
//lomuto
function lomuto(Arrayy,left,right){
    var pivot=Arrayy[left];
    var s=left;
    for(var i=left+1;i<=right;i++){
      counterquickSelect_lomuto++;
       if(Arrayy[i]<pivot){
        
        s=s+1;
          
          var tmp=Arrayy[s];
          Arrayy[s]=Arrayy[i];
          Arrayy[i]=tmp;}}
   
   var tmp=Arrayy[left];
   Arrayy[left]=Arrayy[s];
   Arrayy[s]=tmp;
    
   return s;}
   
   
//-------------
function quickselect1(Arrayy,left,right,k){
  var s=lomuto(Arrayy,left,right);
  
     if (s==k){
       return Arrayy[s];}
     else if (s>k){
       right=s-1;}
     else
       left=s+1;
     return quickselect1(Arrayy,left,right,k);}
//-------------
//lomuto 
console.time("lomuto runtime");        
console.log("The median of quick selection with lomuto is "+ quickselect1(Arrayy,0,Arrayy.length-1,k));
console.timeEnd("lomuto runtime");    
console.log("The basic operation count of lomuto is: "+counterquickSelect_lomuto+"\n-------------");

 //----------
   function quicksort2(Arrayy,left, right) { 
    var pivot = Arrayy[right];
    i = left - 1;
    j = right;
    while (true) {
      counterquicksort_sedqwick++;
      counterquicksort_sedqwick++;
      while (Arrayy[++i] < pivot) {counterquicksort_sedqwick++;} 
      while (Arrayy[--j] > pivot) {
        counterquicksort_sedqwick++; 
        if(i===j)
        break;
      }
      if (i >= j) break;
      
      var tmp = Arrayy[i];
      Arrayy[i] = Arrayy[j];
      Arrayy[j] = tmp;
      
    }
    var tmp = Arrayy[i];
    Arrayy[i] = Arrayy[right];
    Arrayy[right] = tmp;
    
    return i;
  }
  //------------- 
  //
function quickselect2(Arrayy,left,right,k){
  var s=quicksort2(Arrayy,left,right);
  
     if (s==k){
       return Arrayy[s];}
     else if (s>k){
       right=s-1;}
     else
       left=s+1;
     return quickselect2(Arrayy,left,right,k);}

//-------------
//(sedqwick)
console.time("sedqwick runtime is ");          

console.log("The median of quickselection with (sedqwick) is "+quickselect2(Arraycopy,0,Arraycopy.length-1,k));
console.timeEnd("sedqwick runtime is ");
console.log("The basic operation count of sedqwick  is: "+counterquicksort_sedqwick); 
//-------------

function randomnumber(low,high){
   return Math.floor(Math.random()*(high-low+1))+low;
   }
//----------

// fill arrays
function fillarray(size,Arrayy){
 for(var i=0;i<size;i++){
   var number=randomnumber(0,100);
  Arrayy[i]=number;}}